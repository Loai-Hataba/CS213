#ifndef _HEADERS_H
#define _HEADERS_H

#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <map>
#include <limits>
#include <bitset>
#include <chrono>
#include <thread>
#include "Methods.h"
using namespace std;
#endif 
