To run the program properly and view the UI please do the following

1-Preferably use Visual Studio Code (Clion may cause issues with the UI)
2-Open a new Terminal and use GitBash instead of Powershell
3-Enter the following command to automatically compile and run the program
    the command-> ./run

Note:
    make sure the bash terminal is in the right directory where all the files are if Not
    1- enter the command-> cd
    2- enter the command-> cd fullPathToDirectory
    3- enter the command-> ./run